<?php
session_start();
session_destroy();
?>
<h1>Logged out successfully.</h1>
<a href="./login.php">Click here</a> to login again.