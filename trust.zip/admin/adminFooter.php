 
            </div>
        </div>
            
        </div>
    </div>

<div class="container-fluid1">
    <div class="footer-content text-center">
        All Rights Reserved.
    </div>
</div>

</body>

</html>
