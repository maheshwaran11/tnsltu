<!DOCTYPE html>
<html lang="en">
<head>
    <?php include './../includes.php' ?>
</head>
<body>
    <div class="container-fluid1">
        <div class="row dashboardRow m-0">
            <div class="col col-lg-3 bg-main">
                <?php include './sidebar.php' ?>
            </div>
            <div class="col col-lg-9">
                <div class="welcomeText d-flex">
                    <div class="col col-lg-9">
                        <h1>Tamilnadu Union Sangam</h1>
                    </div>
                    <div class="col col-lg-3 d-flex justify-content-end logoutTopLink">
                        <button class="btn-primary">Logout</button>
                    </div>
                    
                </div>